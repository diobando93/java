package com.nivel1.nivel1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Nivel1Application {

	public static void main(String[] args) {
		SpringApplication.run(Nivel1Application.class, args);
	}

}
