package com.nivel1.nivel1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Nivel1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
